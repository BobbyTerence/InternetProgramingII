function convertPennies() {
    //Declare constants for doing math
    const DOLLAR = 100;
    const QUARTER = 25;
    const DIME = 10;
    const NICKLE = 5;

    //Grab the value you are converting from, from the form
    let pennies = document.getElementById("pennies").value;

    //Total number of dollars
    let dollar = parseInt(pennies) / parseInt(DOLLAR);
    pennies = parseInt(pennies) % parseInt(DOLLAR);
    //Display it
    let dollarDisplay = "<h3 id='label'>" + dollar.toString() + "</h3>";
    document.getElementById("dollar-display").innerHTML = dollarDisplay;

    //Total number of quarters
    let quarter = parseInt(pennies) / parseInt(QUARTER);
    pennies = parseInt(pennies) % parseInt(QUARTER);
    //Display it
    let quarterDisplay = "<h3 id='label'>" + quarter + "</h3>";
    document.getElementById("quarter-display").innerHTML = quarterDisplay;

    //Total number of dimes
    let dime = parseInt(pennies) / parseInt(DIME);
    pennies = parseInt(pennies) % parseInt(DIME);
    //Display it
    let dimeDisplay = "<h3 id='label'>" + dime + "</h3>";
    document.getElementById("dime-display").innerHTML = dimeDisplay;

    //Total number of nickles
    let nickle = parseInt(pennies) / parseInt(NICKLE);
    //Display it
    let nickleDisplay = "<h3 id='label'>" + nickle + "</h3>";
    document.getElementById("nickle-display").innerHTML = nickleDisplay;
    //This is the remaining numbere of pennies
    pennies = parseInt(pennies) % parseInt(NICKLE);
    //Display it
    let pennyDisplay = "<h3 id='label'>" + penny + "</h3>";
    document.getElementById("penny-display").innerHTML = pennyDisplay;
}

function clearForm() {
    document.getElementById("pennies").value = "";
}